# submitFormAndRunScript

**Propuesta de API nativa web para enviar formularios y ejecutar JS remoto**

Esta API permite que desde el navegador se envíe un formulario a un endpoint y se ejecute automáticamente código JavaScript que responda el servidor, sin que el código aparezca en la consola o el DOM, protegiendo la experiencia y evitando inyecciones visibles.

---

## ¿Por qué esta API?

- Permite workflows dinámicos sin necesidad de cargar frameworks pesados.
- Reduce exposición de scripts visibles en consola o HTML.
- Facilita operaciones post-submit con código JS remoto seguro.
- Complementa las APIs Fetch y FormData actuales.

---

## Uso básico (propuesto):

```js
submitFormAndRunScript(document.querySelector('form'), '/submit.php')
  .then(() => console.log('Formulario enviado y script ejecutado'));
```

---

## Estado:

- Prototipo en JS disponible en `polyfill/`
- Documentación de especificación en `spec.md`
- Ejemplo funcional en `example/`

---

## Cómo contribuir

Abrir issues o pull requests con mejoras o ideas.

---

## Licencia

MIT License - [LICENSE](LICENSE)
