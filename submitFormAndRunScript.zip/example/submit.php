<?php
header('Content-Type: application/javascript');

$name = $_POST['nombre'] ?? 'Invitado';

echo <<<JS
alert("Hola, $name! Código remoto ejecutado desde submitFormAndRunScript.");
JS;
?>
