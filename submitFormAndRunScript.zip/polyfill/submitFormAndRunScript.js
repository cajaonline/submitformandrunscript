/**
 * submitFormAndRunScript
 * Envía formulario y ejecuta JS remoto de respuesta.
 * 
 * @param {HTMLFormElement} formElement 
 * @param {string} url 
 * @param {Object} options 
 * @returns {Promise<void>}
 */
function submitFormAndRunScript(formElement, url, options = {}) {
  return new Promise((resolve, reject) => {
    if (!(formElement instanceof HTMLFormElement)) {
      return reject(new TypeError('El primer argumento debe ser un elemento form.'));
    }
    if (typeof url !== 'string') {
      return reject(new TypeError('El segundo argumento debe ser una URL.'));
    }

    const method = (options.method || formElement.method || 'POST').toUpperCase();

    const fetchOptions = {
      method,
      headers: options.headers || {},
      body: method === 'GET' ? null : new FormData(formElement),
    };

    fetch(url, fetchOptions)
      .then(response => {
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        const contentType = response.headers.get('content-type') || '';
        if (!contentType.includes('application/javascript')) {
          throw new Error(`Tipo MIME inesperado: ${contentType}`);
        }
        return response.text();
      })
      .then(jsCode => {
        // Ejecutar JS remoto de forma segura
        try {
          const scriptFunc = new Function(jsCode);
          scriptFunc();
          resolve();
        } catch (err) {
          reject(new Error('Error ejecutando script remoto: ' + err.message));
        }
      })
      .catch(err => reject(err));
  });
}

// Export para módulos si es necesario
if (typeof module !== 'undefined' && module.exports) {
  module.exports = submitFormAndRunScript;
}
