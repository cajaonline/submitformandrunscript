# submitFormAndRunScript API Spec

## Resumen

La API `submitFormAndRunScript(formElement, url)` permite enviar un formulario HTML vía POST y ejecutar el código JavaScript recibido en la respuesta de forma segura, sin inyectar código directamente en el DOM ni mostrarlo en la consola.

---

## Sintaxis

```js
submitFormAndRunScript(formElement, url, options)
  .then(result)
  .catch(error);
```

- **formElement**: Elemento `<form>` HTML.
- **url**: URL a la que enviar el formulario.
- **options** (opcional): Objeto con configuración, por ejemplo:
  - `method` (default: "POST")
  - `headers` (objeto con headers extra)
  - `timeout` (milisegundos)

---

## Funcionamiento

1. Envía los datos del formulario usando Fetch API con el método indicado.
2. Espera respuesta en tipo MIME `application/javascript`.
3. Ejecuta el código JS recibido en contexto seguro.
4. Retorna una Promise que resuelve si la ejecución fue exitosa.

---

## Seguridad

- El servidor debe responder sólo con scripts autorizados.
- El script se ejecuta aislado para minimizar riesgos.
- No expone el script en el DOM ni consola.
- El servidor debe validar autenticidad y origen.

---

## Ejemplo de uso

```js
const form = document.querySelector('#myForm');
submitFormAndRunScript(form, '/submit.php')
  .then(() => console.log('Ejecutado con éxito'))
  .catch(e => console.error('Error:', e));
```

---

## Implementación sugerida (polyfill)

- Usa Fetch con `FormData`.
- Extrae texto JS de la respuesta.
- Ejecuta con `Function()` para aislar ámbito.
- Control de errores y timeout.

---

## Futuras extensiones

- Soporte para respuesta JSON que contenga instrucciones JS.
- API para cancelar envío o ejecución.
- Mecanismos de sandbox avanzado.

---

## Autores

Dante Mariano Tomasini — MSMG Informática

---

## Licencia

MIT License
